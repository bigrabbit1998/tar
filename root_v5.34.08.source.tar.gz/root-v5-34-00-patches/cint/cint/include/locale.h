#ifndef G__LOCALE_H
#define G__LOCALE_H
#ifndef G__STDSTRUCT
#pragma setstdstruct
#endif
#define 	LC_ALL (6)
#define 	LC_COLLATE (3)
#define 	LC_CTYPE (0)
#define 	LC_MONETARY (4)
#define 	LC_NUMERIC (1)
#define 	LC_TIME (2)
#endif
